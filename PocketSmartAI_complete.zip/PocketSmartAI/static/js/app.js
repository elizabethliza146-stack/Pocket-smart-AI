const TOKEN_KEY = "pocketsmart_token";

function token() {
  return localStorage.getItem(TOKEN_KEY);
}

function authHeaders(json = true) {
  const h = {};
  if (json) h["Content-Type"] = "application/json";
  if (token()) h["Authorization"] = `Bearer ${token()}`;
  return h;
}

function requireAuth() {
  if (!token()) {
    window.location.href = "/login";
    return false;
  }
  return true;
}

function showMessage(text, type="error") {
  const el = document.getElementById("form-message");
  if (el) {
    el.textContent = text;
    el.className = `message ${type}`;
  }
}

async function handleAuth(form, endpoint) {
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const body = Object.fromEntries(new FormData(form).entries());
    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify(body)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || "Request failed");
      localStorage.setItem(TOKEN_KEY, data.access_token);
      window.location.href = "/dashboard";
    } catch (err) {
      showMessage(err.message);
    }
  });
}

function money(n) {
  return new Intl.NumberFormat("en-IN", {style:"currency", currency:"INR", maximumFractionDigits:0}).format(Number(n) || 0);
}

function renderResult(data) {
  const target = document.getElementById("result");
  if (!target) return;
  target.innerHTML = `
    <div class="result-card">
      <span class="eyebrow">${data.ai_powered ? "GEMINI AI" : "LOCAL FALLBACK"}</span>
      <h2>${escapeHtml(data.title)}</h2>
      <p>Budget: <b>${money(data.budget)}</b> · Allocated: <b>${money(data.allocated_total)}</b></p>
    </div>
    ${data.categories.map(cat => `
      <div class="result-card">
        <h2>${escapeHtml(cat.name || "Category")}</h2>
        <div class="allocation">Suggested allocation: ${money(cat.allocated_budget)}</div>
        ${(cat.items || []).map(item => `
          <div class="item">
            <div class="item-top"><b>${escapeHtml(item.name || "Recommendation")}</b><span class="price">${money(item.price)}</span></div>
            <div class="platform">${escapeHtml(item.platform || "")}</div>
            <p>${escapeHtml(item.reason || item.description || "")}</p>
            ${item.url ? `<a href="${escapeAttr(item.url)}" target="_blank" rel="noopener">View reference</a>` : ""}
          </div>`).join("")}
      </div>`).join("")}
    <div class="result-card"><small>${escapeHtml(data.disclaimer || "")}</small></div>`;
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}
function escapeAttr(value) { return escapeHtml(value).replace(/javascript:/gi, ""); }

async function handlePlanner(form) {
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (!requireAuth()) return;
    const endpoint = form.dataset.endpoint;
    let options = {method:"POST", headers:authHeaders(true)};
    if (form.dataset.type === "form") {
      options.headers = authHeaders(false);
      options.body = new FormData(form);
    } else {
      const fd = new FormData(form);
      const rooms = fd.getAll("rooms");
      options.body = JSON.stringify({
        budget: Number(fd.get("budget")),
        rooms,
        style: fd.get("style"),
        notes: fd.get("notes")
      });
    }
    const target = document.getElementById("result");
    target.innerHTML = '<div class="empty">Generating your plan...</div>';
    try {
      const res = await fetch(endpoint, options);
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || "Could not generate plan");
      renderResult(data);
    } catch (err) {
      target.innerHTML = `<div class="message error">${escapeHtml(err.message)}</div>`;
    }
  });
}

async function loadDashboard() {
  if (!requireAuth()) return;
  const res = await fetch("/api/session-info", {headers:authHeaders(false)});
  if (!res.ok) return;
  const data = await res.json();
  document.getElementById("welcome").textContent = `Welcome, ${data.name}`;
  const summary = await fetch("/api/session-data", {headers:authHeaders(false)}).then(r => r.json());
  document.getElementById("session-summary").textContent = `${summary.recommendation_count} saved recommendation(s)`;
  const history = await fetch("/api/history", {headers:authHeaders(false)}).then(r => r.json());
  document.getElementById("recent-history").innerHTML = history.slice(0,5).map(x =>
    `<div class="history-row"><b>${escapeHtml(x.planner)}</b><span>${new Date(x.created_at).toLocaleString()}</span></div>`
  ).join("") || "<p>No plans yet.</p>";
}

async function loadHistory() {
  if (!requireAuth()) return;
  const target = document.getElementById("history-list");
  const res = await fetch("/api/history", {headers:authHeaders(false)});
  const data = await res.json();
  if (!res.ok) { target.innerHTML = `<div class="message error">${escapeHtml(data.detail || "Error")}</div>`; return; }
  target.innerHTML = data.map(x => `
    <div class="history-row">
      <div><b>${escapeHtml(x.planner.toUpperCase())}</b><p>${escapeHtml(x.result.title || "")}</p></div>
      <span>${new Date(x.created_at).toLocaleString()}</span>
    </div>`).join("") || "<p>No saved recommendations.</p>";
}

document.addEventListener("DOMContentLoaded", () => {
  const login = document.getElementById("login-form");
  if (login) handleAuth(login, "/api/auth/login");
  const register = document.getElementById("register-form");
  if (register) handleAuth(register, "/api/auth/register");
  const planner = document.querySelector(".planner-form");
  if (planner) handlePlanner(planner);
  if (document.getElementById("welcome")) loadDashboard();
  if (document.getElementById("history-list")) loadHistory();
});
