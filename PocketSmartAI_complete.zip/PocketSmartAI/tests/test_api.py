import os
from pathlib import Path

os.environ["DATABASE_URL"] = "sqlite:///./test_pocketsmart.db"
os.environ["SECRET_KEY"] = "test-secret"

from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def auth_headers():
    reg = client.post("/api/auth/register", json={
        "name": "Test User",
        "email": "test@example.com",
        "password": "secret123"
    })
    if reg.status_code == 409:
        login = client.post("/api/auth/login", json={
            "email": "test@example.com",
            "password": "secret123"
        })
        token = login.json()["access_token"]
    else:
        token = reg.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}


def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_auth_and_session():
    headers = auth_headers()
    response = client.get("/api/session-info", headers=headers)
    assert response.status_code == 200
    assert response.json()["logged_in"] is True


def test_home_planner():
    headers = auth_headers()
    response = client.post("/api/generate-home", headers=headers, json={
        "budget": 30000,
        "rooms": ["Living Room", "Bedroom"],
        "style": "Modern",
        "notes": ""
    })
    assert response.status_code == 200
    assert response.json()["planner"] == "home"


def test_party_planner():
    headers = auth_headers()
    response = client.post("/api/generate-party", headers=headers, json={
        "budget": 25000,
        "guests": 30,
        "event_type": "Birthday",
        "venue": "Home",
        "city": "Chennai",
        "notes": ""
    })
    assert response.status_code == 200
    assert response.json()["planner"] == "party"


def test_jewelry_planner():
    headers = auth_headers()
    response = client.post("/api/generate-jewelry", headers=headers, data={
        "budget": "5000",
        "occasion": "Wedding",
        "style": "Elegant",
        "outfit_color": "Blue",
        "notes": ""
    })
    assert response.status_code == 200
    assert response.json()["planner"] == "jewelry"


def test_history():
    headers = auth_headers()
    response = client.get("/api/history", headers=headers)
    assert response.status_code == 200
    assert isinstance(response.json(), list)
