import json
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..database import get_db
from ..deps import get_current_user
from ..models import User, RecommendationHistory

router = APIRouter(prefix="/api", tags=["session"])


@router.get("/session-info")
def session_info(user: User = Depends(get_current_user)):
    return {"logged_in": True, "user_id": user.id, "name": user.name, "email": user.email}


@router.get("/session-data")
def session_data(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    count = db.query(RecommendationHistory).filter(RecommendationHistory.user_id == user.id).count()
    return {"user_id": user.id, "recommendation_count": count}


@router.get("/history")
def history(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = (
        db.query(RecommendationHistory)
        .filter(RecommendationHistory.user_id == user.id)
        .order_by(RecommendationHistory.created_at.desc())
        .all()
    )
    return [
        {
            "id": row.id,
            "planner": row.planner,
            "input": json.loads(row.input_json),
            "result": json.loads(row.result_json),
            "created_at": row.created_at.isoformat(),
        }
        for row in rows
    ]
