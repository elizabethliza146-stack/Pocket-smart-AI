from fastapi import APIRouter, Depends, File, Form, UploadFile, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..deps import get_current_user
from ..models import User
from ..schemas import HomeRequest, PartyRequest, JewelryRequest
from ..services.recommendation_service import generate_home, generate_party, generate_jewelry

router = APIRouter(prefix="/api", tags=["planners"])


@router.post("/generate-home")
def generate_home_route(
    data: HomeRequest,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    return generate_home(db, user.id, data.model_dump())


@router.post("/generate-party")
def generate_party_route(
    data: PartyRequest,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    return generate_party(db, user.id, data.model_dump())


@router.post("/generate-jewelry")
async def generate_jewelry_route(
    budget: float = Form(...),
    occasion: str = Form(...),
    style: str = Form("Elegant"),
    outfit_color: str = Form(""),
    notes: str = Form(""),
    outfit_image: UploadFile | None = File(None),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    data = JewelryRequest(
        budget=budget,
        occasion=occasion,
        style=style,
        outfit_color=outfit_color,
        notes=notes,
    )

    image_bytes = None
    image_mime = None
    if outfit_image:
        allowed = {"image/jpeg", "image/png", "image/webp"}
        if outfit_image.content_type not in allowed:
            raise HTTPException(status_code=400, detail="Use JPG, PNG or WEBP for outfit image.")
        image_bytes = await outfit_image.read()
        if len(image_bytes) > 5 * 1024 * 1024:
            raise HTTPException(status_code=413, detail="Image is larger than 5 MB.")
        image_mime = outfit_image.content_type

    return generate_jewelry(db, user.id, data.model_dump(), image_bytes, image_mime)


@router.post("/recommendations-details")
def recommendation_details(data: dict):
    return {"message": "Use the planner endpoints to generate recommendations.", "received": data}
