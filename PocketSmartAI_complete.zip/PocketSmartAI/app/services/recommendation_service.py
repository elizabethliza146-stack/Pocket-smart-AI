import json
from sqlalchemy.orm import Session
from ..ai.gemini_service import GeminiService
from ..models import RecommendationHistory
from .catalog_service import find_products, find_services


gemini = GeminiService()


def _save(db: Session, user_id: int, planner: str, payload: dict, result: dict):
    row = RecommendationHistory(
        user_id=user_id,
        planner=planner,
        input_json=json.dumps(payload, ensure_ascii=False),
        result_json=json.dumps(result, ensure_ascii=False),
    )
    db.add(row)
    db.commit()


def _fallback_home(payload: dict) -> dict:
    budget = payload["budget"]
    room_count = len(payload["rooms"])
    allocations = {
        "Furniture": round(budget * 0.40, 2),
        "Lighting": round(budget * 0.20, 2),
        "Decor": round(budget * 0.20, 2),
        "Essentials": round(budget * 0.20, 2),
    }
    categories = []
    for name, amount in allocations.items():
        items = find_products([name], amount, 3)
        categories.append({"name": name, "allocated_budget": amount, "items": items})
    return {
        "planner": "home",
        "title": f"Home plan for {room_count} room(s)",
        "budget": budget,
        "allocated_total": round(sum(allocations.values()), 2),
        "categories": categories,
        "ai_powered": False,
        "disclaimer": "Demo catalog recommendations; prices and availability are not live.",
    }


def _fallback_party(payload: dict) -> dict:
    budget = payload["budget"]
    allocations = {
        "Food": round(budget * 0.50, 2),
        "Decoration": round(budget * 0.20, 2),
        "Venue": round(budget * 0.20, 2),
        "Entertainment": round(budget * 0.10, 2),
    }
    categories = []
    for name, amount in allocations.items():
        items = find_services([name], amount, 3)
        categories.append({"name": name, "allocated_budget": amount, "items": items})
    return {
        "planner": "party",
        "title": f"{payload['event_type']} plan for {payload['guests']} guests",
        "budget": budget,
        "allocated_total": round(sum(allocations.values()), 2),
        "categories": categories,
        "ai_powered": False,
        "disclaimer": "Demo catalog recommendations; vendors, prices and availability are not live.",
    }


def _fallback_jewelry(payload: dict) -> dict:
    budget = payload["budget"]
    items = find_products(["Jewelry"], budget, 8)
    return {
        "planner": "jewelry",
        "title": f"{payload['occasion']} jewelry ideas",
        "budget": budget,
        "allocated_total": budget,
        "categories": [{
            "name": "Jewelry",
            "allocated_budget": budget,
            "items": items,
        }],
        "ai_powered": False,
        "disclaimer": "Demo catalog recommendations; product prices and availability are not live.",
    }


def generate_home(db: Session, user_id: int, payload: dict) -> dict:
    fallback = _fallback_home(payload)
    ai = gemini.recommend("Home Interior", payload, sum([c["items"] for c in fallback["categories"]], []))
    result = _merge_ai(fallback, ai, "home")
    _save(db, user_id, "home", payload, result)
    return result


def generate_party(db: Session, user_id: int, payload: dict) -> dict:
    fallback = _fallback_party(payload)
    ai = gemini.recommend("Party Planning", payload, sum([c["items"] for c in fallback["categories"]], []))
    result = _merge_ai(fallback, ai, "party")
    _save(db, user_id, "party", payload, result)
    return result


def generate_jewelry(db: Session, user_id: int, payload: dict, image_bytes=None, image_mime=None) -> dict:
    fallback = _fallback_jewelry(payload)
    ai = gemini.recommend("Jewelry Recommendations", payload, fallback["categories"][0]["items"], image_bytes, image_mime)
    result = _merge_ai(fallback, ai, "jewelry")
    _save(db, user_id, "jewelry", payload, result)
    return result


def _merge_ai(fallback: dict, ai: dict | None, planner: str) -> dict:
    if not ai or not isinstance(ai.get("categories"), list):
        return fallback

    result = dict(fallback)
    result["title"] = str(ai.get("title") or fallback["title"])
    result["categories"] = ai["categories"]
    result["ai_powered"] = True
    result["disclaimer"] = "AI-generated recommendations using the configured Gemini model; catalog data is still demo/local data."
    result["planner"] = planner
    return result
