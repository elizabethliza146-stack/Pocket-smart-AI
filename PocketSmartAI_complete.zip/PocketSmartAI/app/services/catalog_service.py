import json
from pathlib import Path
from typing import Iterable


CATALOG_PATH = Path(__file__).resolve().parents[2] / "data" / "catalog.json"


def load_catalog() -> list[dict]:
    with CATALOG_PATH.open("r", encoding="utf-8") as f:
        return json.load(f)


def find_products(
    categories: Iterable[str],
    budget: float,
    limit: int = 8,
) -> list[dict]:
    wanted = {c.lower() for c in categories}
    items = load_catalog()
    matches = [
        item for item in items
        if item["category"].lower() in wanted and float(item["price"]) <= budget
    ]
    matches.sort(key=lambda x: (x["price"], x["name"]))
    return matches[:limit]


def find_services(categories: Iterable[str], budget: float, limit: int = 8) -> list[dict]:
    return find_products(categories, budget, limit)
