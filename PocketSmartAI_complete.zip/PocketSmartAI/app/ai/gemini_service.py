import json
import re
from typing import Any
from . import __name__  # keeps package import explicit
from ..config import get_settings

try:
    from google import genai
    from google.genai import types
except Exception:
    genai = None
    types = None


class GeminiService:
    def __init__(self):
        settings = get_settings()
        self.api_key = settings.gemini_api_key.strip()
        self.model = settings.gemini_model
        self.client = genai.Client(api_key=self.api_key) if self.api_key and genai else None

    @property
    def enabled(self) -> bool:
        return self.client is not None

    def recommend(self, planner: str, payload: dict[str, Any], catalog: list[dict], image_bytes: bytes | None = None, image_mime: str | None = None) -> dict | None:
        if not self.enabled:
            return None

        catalog_text = json.dumps(catalog, ensure_ascii=False)
        prompt = f"""
You are PocketSmart AI, a budget-aware recommendation assistant.
Planner: {planner}
User input:
{json.dumps(payload, ensure_ascii=False)}

Available local catalog:
{catalog_text}

Return ONLY valid JSON with this exact high-level structure:
{{
  "title": "short title",
  "categories": [
    {{
      "name": "category",
      "allocated_budget": 0,
      "items": [
        {{
          "name": "item name",
          "platform": "platform",
          "price": 0,
          "reason": "short reason",
          "url": "url from catalog when available"
        }}
      ]
    }}
  ]
}}

Rules:
- Never invent catalog URLs.
- Keep the sum of allocated budgets <= the user's budget.
- Prefer catalog items when suitable.
- Be concise.
- For jewelry, use the outfit image only to discuss broad color/style coordination.
"""

        contents: list[Any] = [prompt]
        if image_bytes and image_mime and types:
            contents.append(types.Part.from_bytes(data=image_bytes, mime_type=image_mime))

        try:
            response = self.client.models.generate_content(
                model=self.model,
                contents=contents,
                config=types.GenerateContentConfig(
                    temperature=0.3,
                    response_mime_type="application/json",
                ),
            )
            raw = getattr(response, "text", "") or ""
            return self._parse_json(raw)
        except Exception:
            return None

    @staticmethod
    def _parse_json(raw: str) -> dict | None:
        raw = raw.strip()
        raw = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.I)
        raw = re.sub(r"\s*```$", "", raw)
        try:
            data = json.loads(raw)
            return data if isinstance(data, dict) else None
        except json.JSONDecodeError:
            return None
