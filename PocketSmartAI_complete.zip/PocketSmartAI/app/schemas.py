from typing import Optional
from pydantic import BaseModel, EmailStr, Field


class RegisterRequest(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    password: str = Field(min_length=6, max_length=128)


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class HomeRequest(BaseModel):
    budget: float = Field(gt=0, le=10_000_000)
    rooms: list[str] = Field(min_length=1, max_length=10)
    style: str = Field(default="Modern", max_length=80)
    notes: Optional[str] = Field(default="", max_length=1000)


class PartyRequest(BaseModel):
    budget: float = Field(gt=0, le=10_000_000)
    guests: int = Field(gt=0, le=10_000)
    event_type: str = Field(min_length=2, max_length=80)
    venue: str = Field(default="Home", max_length=120)
    city: str = Field(default="Chennai", max_length=100)
    notes: Optional[str] = Field(default="", max_length=1000)


class JewelryRequest(BaseModel):
    budget: float = Field(gt=0, le=10_000_000)
    occasion: str = Field(min_length=2, max_length=100)
    style: str = Field(default="Elegant", max_length=100)
    outfit_color: Optional[str] = Field(default="", max_length=80)
    notes: Optional[str] = Field(default="", max_length=1000)


class RecommendationResponse(BaseModel):
    planner: str
    title: str
    budget: float
    allocated_total: float
    categories: list[dict]
    ai_powered: bool
    disclaimer: str
