from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from .config import get_settings
from .database import Base, engine
from .routers import auth, planners, session, pages


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    yield


settings = get_settings()

app = FastAPI(
    title=settings.app_name,
    description="Budget-aware AI recommendation assistant for Home, Party and Jewelry planning.",
    version="1.0.0",
    lifespan=lifespan,
)

app.mount("/static", StaticFiles(directory="static"), name="static")

app.include_router(pages.router)
app.include_router(auth.router)
app.include_router(planners.router)
app.include_router(session.router)


@app.get("/health")
def health():
    return {"status": "ok", "app": settings.app_name, "gemini_configured": bool(settings.gemini_api_key)}
