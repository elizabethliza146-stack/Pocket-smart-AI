# PocketSmart AI

PocketSmart AI is a FastAPI + Jinja2 + SQLite + Gemini-powered budget and recommendation assistant.

It implements the project brief's three planners:
- Home Interior
- Party Planning
- Jewelry Recommendations (optional outfit image)
- User registration/login/logout
- JWT token endpoint
- Session information
- Recommendation history
- Mock product/service catalogs for Amazon, Flipkart, IKEA, Swiggy, Zomato and OYO-style results
- Gemini-powered personalization when `GEMINI_API_KEY` is configured
- Safe local fallback recommendations when Gemini is unavailable

## Important model note

The original project document names Gemini 1.5 Flash Pro. That model family is no longer available through the current Gemini API. This project therefore makes the model configurable with `GEMINI_MODEL` and defaults to a current Flash model. If your account supports another model, change the value in `.env`.

## 1. Requirements

- Python 3.11+
- VS Code
- Internet connection for Gemini API calls
- A Gemini API key for live AI mode (optional; fallback mode works without it)

## 2. VS Code setup

Open this folder in VS Code.

Windows PowerShell:

```powershell
py -3.11 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
copy .env.example .env
```

If PowerShell blocks activation, use:

```powershell
.venv\Scripts\python.exe -m pip install -r requirements.txt
```

Edit `.env` and add your API key:

```env
GEMINI_API_KEY=your_key_here
GEMINI_MODEL=gemini-3.8-flash
```

Never commit `.env` to Git.

## 3. Run

```powershell
uvicorn app.main:app --reload
```

Open:

http://127.0.0.1:8000

API documentation:

http://127.0.0.1:8000/docs

## 4. Test

Run:

```powershell
pytest -q
```

The tests verify:
- health endpoint
- registration/login
- protected session endpoint
- home planner
- party planner
- jewelry planner
- history

## 5. Project structure

```text
PocketSmartAI/
├── app/
│   ├── __init__.py
│   ├── main.py
│   ├── config.py
│   ├── database.py
│   ├── deps.py
│   ├── models.py
│   ├── schemas.py
│   ├── auth.py
│   ├── ai/
│   │   ├── __init__.py
│   │   └── gemini_service.py
│   ├── services/
│   │   ├── __init__.py
│   │   ├── catalog_service.py
│   │   └── recommendation_service.py
│   └── routers/
│       ├── __init__.py
│       ├── auth.py
│       ├── planners.py
│       ├── session.py
│       └── pages.py
├── templates/
├── static/
│   ├── css/style.css
│   └── js/app.js
├── data/catalog.json
├── tests/test_api.py
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## 6. Architecture

Browser → FastAPI routes → validation/services → Gemini (optional) + local catalog → SQLite history → Jinja2/JSON response.

The catalog is deliberately mocked. It does not scrape Amazon, Flipkart, IKEA, Swiggy, Zomato or OYO. This keeps the project runnable and avoids depending on undocumented/private endpoints. Replace `catalog.json` with approved partner/API integrations if real-time commercial data is required.

## 7. Demo flow

1. Register a user.
2. Login.
3. Open Home Planner, Party Planner or Jewelry Planner.
4. Enter budget and preferences.
5. Submit.
6. The backend validates the request.
7. Gemini generates a structured plan when available.
8. The backend combines AI output with the local catalog.
9. The result is saved to history.
10. Open History to review earlier plans.

## 8. Security notes

This is a college/demo application, not a production financial platform. Before production:
- use PostgreSQL
- move secret/session handling to a proper secret manager
- add CSRF protection for cookie-based browser auth
- use HTTPS
- add rate limiting
- add account lockout/abuse protection
- add image size/type scanning
- replace mock catalogs with licensed APIs
- add audit logging
